﻿using CustomerAccountsUsingRaptorDb.Entities;
using CustomerAccountsUsingRaptorDb.Views.Schemas;
using RaptorDB;

namespace CustomerAccountsUsingRaptorDb.Views
{
    [RegisterView]
    public class CustomerAccountView : View<CustomerAccount>
    {
        public CustomerAccountView()
        {
            this.Name = "CustomerAccountView";
            this.Description = "A primary view for a CustomerAccount object";
            this.isPrimaryList = true;
            this.isActive = true;
            this.BackgroundIndexing = false;
            this.Version = 1;
            this.ConsistentSaveToThisView = true;
            this.TransactionMode = false;

            this.Schema = typeof (CustomerAccountViewRowSchema);

            this.Mapper = (api, docId, doc) =>
            {
                api.EmitObject(docId, doc);
            };
        }
    }
}
