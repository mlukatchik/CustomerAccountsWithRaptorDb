﻿namespace CustomerAccountsUsingRaptorDb.Common.Enum
{
    public enum ManageAction
    {
        Add = 0,
        Update = 1
    }
}
