﻿namespace CustomerAccountsUsingRaptorDb.Common.Enum
{
    public enum AccountLevel
    {
        Basic = 0,
        Silver = 1,
        Gold = 2,
        Platinum = 3
    }
}
